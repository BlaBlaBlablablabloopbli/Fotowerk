package de.fotowerk.app

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class Photo(val id: Long, val uri: Uri, val date: Long, val bucket: String) {
    var sharp = -1.0
    var bright = -1.0
    var hash = 0L
    var analyzed = false
    val flags = mutableListOf<String>()
}

class MainActivity : Activity() {

    companion object {
        const val BG = 0xFF141821.toInt()
        const val CARD = 0xFF1D2230.toInt()
        const val FG = 0xFFE6E9F0.toInt()
        const val MUTED = 0xFF9AA3B5.toInt()
        const val ACCENT = 0xFF7FD6C6.toInt()
        const val RED = 0xFFE5534B.toInt()
        const val GREEN = 0xFF4FA35A.toInt()
        const val GRAY = 0xFF343B4D.toInt()
        const val BLUR_LIMIT = 60.0
        const val DARK_LIMIT = 40.0
        const val BRIGHT_LIMIT = 225.0
        const val SERIES_MS = 10_000L
        const val SERIES_HAMMING = 14
        const val REQ_PERM = 1
        const val REQ_TRASH = 2
    }

    private val ui = Handler(Looper.getMainLooper())
    private val analysisExec = Executors.newSingleThreadExecutor()
    private val imageExec = Executors.newFixedThreadPool(2)
    private val prefs by lazy { getSharedPreferences("fotowerk", MODE_PRIVATE) }

    private var photos = listOf<Photo>()
    private var keep = mutableSetOf<Long>()
    private var trash = mutableSetOf<Long>()
    private var album: String? = null
    private var analysisDone = 0
    private var analysisRunning = false
    private var screen = "start"

    // Swipen
    private var queue = listOf<Photo>()
    private var pos = 0
    private val history = ArrayDeque<Pair<Photo, Boolean>>()
    private val big = LruCache<Long, Bitmap>(4)
    private val small = LruCache<Long, Bitmap>(90)
    private var cardImage: ImageView? = null
    private var cardChips: TextView? = null
    private var cardCounter: TextView? = null
    private var cardStamp: TextView? = null
    private var card: FrameLayout? = null
    private var startInfo: TextView? = null
    private var pendingTrash = listOf<Long>()

    // ---------- Start ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        keep = (prefs.getStringSet("keep", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toMutableSet()
        trash = (prefs.getStringSet("trash", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toMutableSet()
        if (hasPermission()) loadPhotos() else askPermission()
    }

    private fun permissionName() =
        if (android.os.Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun hasPermission() = checkSelfPermission(permissionName()) == PackageManager.PERMISSION_GRANTED

    private fun askPermission() {
        val col = column()
        col.add(text("Fotowerk", 28f, FG, true), 0)
        col.add(text("Damit Fotowerk deine Fotos sortieren kann, braucht es Zugriff auf deine Galerie. Die Fotos verlassen dein Handy nie.", 16f, MUTED))
        col.add(text("Wichtig: Bitte „Alle zulassen“ wählen, nicht nur ausgewählte Fotos.", 16f, ACCENT))
        col.add(button("Zugriff erlauben", ACCENT, BG) { requestPermissions(arrayOf(permissionName()), REQ_PERM) }, 24)
        col.add(button("Einstellungen öffnen", GRAY) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM && hasPermission()) loadPhotos()
        else toast("Ohne Zugriff kann Fotowerk keine Fotos anzeigen.")
    }

    override fun onResume() {
        super.onResume()
        if (photos.isEmpty() && hasPermission() && screen == "start") loadPhotos()
    }

    private fun loadPhotos() {
        val list = mutableListOf<Photo>()
        val proj = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DATE_TAKEN,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME
        )
        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, null, null,
                MediaStore.Images.Media.DATE_ADDED + " DESC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val iTaken = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN)
                val iAdded = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val iBucket = c.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    val taken = if (c.isNull(iTaken)) 0L else c.getLong(iTaken)
                    val added = c.getLong(iAdded) * 1000L
                    val bucket = c.getString(iBucket) ?: "Ohne Album"
                    list.add(Photo(id, ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), if (taken > 0) taken else added, bucket))
                }
            }
        } catch (e: Exception) {
            toast("Fotos konnten nicht gelesen werden.")
        }
        list.sortByDescending { it.date }
        photos = list
        val ids = list.map { it.id }.toHashSet()
        keep.retainAll(ids)
        trash.retainAll(ids)
        saveDecisions()
        readCache()
        updateFlags()
        showStart()
        startAnalysis()
    }

    // ---------- Analyse ----------

    private fun cacheFile() = File(filesDir, "analyse.json")

    private fun readCache() {
        try {
            val f = cacheFile()
            if (!f.exists()) return
            val o = JSONObject(f.readText())
            for (p in photos) {
                val s = o.optString(p.id.toString(), "")
                if (s.isEmpty()) continue
                val parts = s.split("|")
                if (parts.size != 3) continue
                p.sharp = parts[0].toDouble()
                p.bright = parts[1].toDouble()
                p.hash = parts[2].toLong()
                p.analyzed = true
            }
        } catch (e: Exception) { }
    }

    private fun writeCache() {
        try {
            val o = JSONObject()
            for (p in photos) if (p.analyzed) o.put(p.id.toString(), "${p.sharp}|${p.bright}|${p.hash}")
            cacheFile().writeText(o.toString())
        } catch (e: Exception) { }
    }

    private fun startAnalysis() {
        if (analysisRunning) return
        val todo = photos.filter { !it.analyzed }
        analysisDone = photos.size - todo.size
        if (todo.isEmpty()) return
        analysisRunning = true
        analysisExec.execute {
            var n = 0
            for (p in todo) {
                try {
                    var b = contentResolver.loadThumbnail(p.uri, Size(256, 256), null)
                    if (b.config != Bitmap.Config.ARGB_8888) b = b.copy(Bitmap.Config.ARGB_8888, false)
                    analyze(p, b)
                } catch (e: Exception) {
                    p.sharp = 9999.0; p.bright = 128.0; p.hash = 0L; p.analyzed = true
                }
                n++
                analysisDone++
                if (n % 25 == 0) ui.post { updateStartInfo() }
                if (n % 300 == 0) writeCache()
            }
            writeCache()
            ui.post {
                analysisRunning = false
                updateFlags()
                if (screen == "start") showStart()
            }
        }
    }

    private fun lum(p: Int) = ((p shr 16 and 255) * 299 + (p shr 8 and 255) * 587 + (p and 255) * 114) / 1000

    private fun analyze(p: Photo, b: Bitmap) {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val g = IntArray(w * h) { lum(px[it]) }
        var sum = 0.0
        for (v in g) sum += v
        var s = 0.0
        var s2 = 0.0
        var n = 0
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val l = (g[i - 1] + g[i + 1] + g[i - w] + g[i + w] - 4 * g[i]).toDouble()
            s += l; s2 += l * l; n++
        }
        val mean = if (n > 0) s / n else 0.0
        p.sharp = if (n > 0) s2 / n - mean * mean else 0.0
        p.bright = if (g.isNotEmpty()) sum / g.size else 128.0
        val tiny = Bitmap.createScaledBitmap(b, 9, 8, true)
        var hash = 0L
        var bit = 0
        for (y in 0 until 8) for (x in 0 until 8) {
            if (lum(tiny.getPixel(x, y)) > lum(tiny.getPixel(x + 1, y))) hash = hash or (1L shl bit)
            bit++
        }
        p.hash = hash
        p.analyzed = true
    }

    private fun updateFlags() {
        for (p in photos) {
            p.flags.clear()
            if (!p.analyzed) continue
            if (p.sharp in 0.0..BLUR_LIMIT) p.flags.add("Unscharf")
            if (p.bright in 0.0..DARK_LIMIT) p.flags.add("Zu dunkel")
            if (p.bright >= BRIGHT_LIMIT) p.flags.add("Überbelichtet")
        }
        val sorted = photos.filter { it.analyzed }.sortedBy { it.date }
        var i = 0
        while (i < sorted.size) {
            var j = i
            while (j + 1 < sorted.size &&
                sorted[j + 1].date - sorted[j].date <= SERIES_MS &&
                java.lang.Long.bitCount(sorted[j + 1].hash xor sorted[j].hash) <= SERIES_HAMMING) j++
            if (j > i) {
                val group = sorted.subList(i, j + 1)
                val best = group.maxByOrNull { it.sharp }
                for (p in group) if (p !== best) p.flags.add("Serie: ähnliches Foto ist schärfer")
            }
            i = j + 1
        }
    }

    // ---------- Startbildschirm ----------

    private fun pool() = photos.filter { album == null || it.bucket == album }
    private fun open(list: List<Photo>) = list.filter { it.id !in keep && it.id !in trash }

    private fun showStart() {
        screen = "start"
        val col = column()
        col.add(text("Fotowerk", 30f, FG, true), 0)
        col.add(text("Galerie ausmisten: links löschen, rechts behalten", 15f, MUTED), 4)

        val buckets = photos.groupingBy { it.bucket }.eachCount().entries.sortedByDescending { it.value }
        val names = listOf("Alle Fotos (${photos.size})") + buckets.map { "${it.key} (${it.value})" }
        val spinner = Spinner(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val sel = if (album == null) 0 else buckets.indexOfFirst { it.key == album } + 1
        spinner.setSelection(if (sel < 0) 0 else sel, false)
        spinner.background = rounded(CARD)
        spinner.setPadding(dp(8), dp(8), dp(8), dp(8))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val a = if (position == 0) null else buckets[position - 1].key
                if (a != album) { album = a; showStart() }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        col.add(text("Album", 14f, MUTED), 22)
        col.add(spinner, 6)

        startInfo = text("", 15f, MUTED)
        col.add(startInfo!!, 14)
        updateStartInfo()

        val p = pool()
        val flagged = open(p).filter { it.flags.isNotEmpty() }
        val rest = open(p)
        val trashCount = trash.size
        col.add(button("Vorsortierte prüfen (${flagged.size})", ACCENT, BG) {
            if (flagged.isEmpty()) toast(if (analysisRunning) "Die Analyse läuft noch, schau gleich nochmal." else "Keine verdächtigen Fotos mehr.")
            else startSwipe(flagged)
        }, 20)
        col.add(text("Unscharf, zu dunkel, überbelichtet oder Teil einer Serie", 13f, MUTED), 4)
        col.add(button("Alle Fotos durchgehen (${rest.size})", GRAY) {
            if (rest.isEmpty()) toast("Alles schon angeschaut.") else startSwipe(rest)
        }, 16)
        col.add(button("Zum Löschen vorgemerkt ansehen ($trashCount)", GRAY) { showTrash() }, 16)
        col.add(button("Vorgemerkte in den Papierkorb ($trashCount)", RED) { requestTrash() }, 16)
        col.add(text("Fotos im Papierkorb lassen sich 30 Tage lang in deiner Galerie-App wiederherstellen.", 13f, MUTED), 6)
        col.add(button("Behalten-Liste zurücksetzen (${keep.size})", CARD, MUTED) {
            keep.clear(); saveDecisions(); toast("Alle behaltenen Fotos werden wieder angezeigt."); showStart()
        }, 28)
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(col) })
    }

    private fun updateStartInfo() {
        val t = startInfo ?: return
        val p = pool()
        val base = "${p.size} Fotos · ${p.count { it.id in keep }} behalten · ${trash.size} zum Löschen"
        t.text = if (analysisRunning) "$base\nAnalysiere … ${analysisDone} / ${photos.size}" else base
    }

    // ---------- Swipen ----------

    private fun startSwipe(list: List<Photo>) {
        screen = "swipe"
        queue = list
        pos = 0
        history.clear()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(button("‹ Fertig", GRAY) { showStart() }, LinearLayout.LayoutParams(-2, -2))
        val counter = text("", 15f, MUTED).apply { gravity = Gravity.END }
        cardCounter = counter
        top.addView(counter, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val c = FrameLayout(this).apply { background = rounded(CARD) }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        cardImage = img
        c.addView(img, FrameLayout.LayoutParams(-1, -1))
        val stamp = text("", 30f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; alpha = 0f; setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        cardStamp = stamp
        c.addView(stamp, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(24) })
        val chips = text("", 14f, Color.WHITE).apply {
            background = rounded(0xCC141821.toInt()); setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        cardChips = chips
        c.addView(chips, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(10), dp(10), dp(10), dp(10)) })
        card = c
        root.addView(c, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(12); bottomMargin = dp(12) })
        c.setOnTouchListener(SwipeTouch())

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("✕  Löschen", RED) { decide(false) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        row.addView(button("↶", GRAY) { undo() }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
        row.addView(button("Behalten  ✓", GREEN) { decide(true) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        showCurrent()
    }

    private fun current(): Photo? = if (pos < queue.size) queue[pos] else null

    private fun showCurrent() {
        val p = current()
        val c = card ?: return
        c.translationX = 0f; c.rotation = 0f; c.alpha = 1f
        cardStamp?.alpha = 0f
        if (p == null) {
            cardImage?.setImageBitmap(null)
            cardChips?.text = "Fertig! Alle Fotos in dieser Liste angeschaut."
            cardCounter?.text = "${queue.size} / ${queue.size}"
            return
        }
        cardCounter?.text = "${pos + 1} / ${queue.size}"
        val date = SimpleDateFormat("dd.MM.yyyy  HH:mm", Locale.GERMANY).format(Date(p.date))
        cardChips?.text = (listOf(date, p.bucket) + p.flags).joinToString("\n")
        val cached = big.get(p.id)
        cardImage?.setImageBitmap(cached)
        if (cached == null) loadBig(p) { b -> if (current() === p) cardImage?.setImageBitmap(b) }
        if (pos + 1 < queue.size) loadBig(queue[pos + 1]) { }
    }

    private fun loadBig(p: Photo, done: (Bitmap?) -> Unit) {
        big.get(p.id)?.let { done(it); return }
        imageExec.execute {
            val b = try { contentResolver.loadThumbnail(p.uri, Size(1440, 1440), null) } catch (e: Exception) { null }
            ui.post { if (b != null) big.put(p.id, b); done(b) }
        }
    }

    private fun decide(keepIt: Boolean) {
        val p = current() ?: return
        val c = card ?: return
        if (keepIt) { keep.add(p.id); trash.remove(p.id) } else { trash.add(p.id); keep.remove(p.id) }
        saveDecisions()
        history.addLast(Pair(p, keepIt))
        val w = c.width.toFloat().coerceAtLeast(400f)
        c.animate().translationX(if (keepIt) w * 1.4f else -w * 1.4f).rotation(if (keepIt) 18f else -18f).alpha(0f)
            .setDuration(170).withEndAction { pos++; showCurrent() }.start()
    }

    private fun undo() {
        val last = history.removeLastOrNull() ?: return toast("Nichts zum Rückgängigmachen")
        keep.remove(last.first.id); trash.remove(last.first.id)
        saveDecisions()
        pos = queue.indexOf(last.first).coerceAtLeast(0)
        showCurrent()
    }

    private inner class SwipeTouch : View.OnTouchListener {
        private var downX = 0f
        private var dragging = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            if (current() == null) return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; dragging = true }
                MotionEvent.ACTION_MOVE -> if (dragging) {
                    val dx = e.rawX - downX
                    v.translationX = dx
                    v.rotation = dx / 40f
                    val st = cardStamp ?: return true
                    st.alpha = (abs(dx) / (v.width * 0.3f)).coerceAtMost(1f)
                    st.text = if (dx < 0) "LÖSCHEN" else "BEHALTEN"
                    st.background = rounded(if (dx < 0) RED else GREEN)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    val dx = e.rawX - downX
                    when {
                        dx < -v.width * 0.28f -> decide(false)
                        dx > v.width * 0.28f -> decide(true)
                        else -> {
                            v.animate().translationX(0f).rotation(0f).setDuration(150).start()
                            cardStamp?.animate()?.alpha(0f)?.setDuration(150)?.start()
                        }
                    }
                }
            }
            return true
        }
    }

    // ---------- Vorgemerkte ----------

    private fun showTrash() {
        screen = "trash"
        val items = photos.filter { it.id in trash }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(12), dp(12), dp(12), dp(12)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(button("‹ Zurück", GRAY) { showStart() }, LinearLayout.LayoutParams(-2, -2))
        top.addView(text("  ${items.size} zum Löschen", 16f, FG, true), LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))
        root.addView(text("Tippe ein Foto an, um es doch zu behalten.", 14f, MUTED), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val size = (resources.displayMetrics.widthPixels - dp(40)) / 3
        val grid = GridView(this).apply {
            numColumns = 3
            horizontalSpacing = dp(4); verticalSpacing = dp(4)
            adapter = object : BaseAdapter() {
                override fun getCount() = items.size
                override fun getItem(position: Int) = items[position]
                override fun getItemId(position: Int) = items[position].id
                override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                    val iv = (convertView as? ImageView) ?: ImageView(this@MainActivity).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        layoutParams = AbsListView.LayoutParams(-1, size)
                        setBackgroundColor(CARD)
                    }
                    val p = items[position]
                    iv.tag = p.id
                    val b = small.get(p.id)
                    iv.setImageBitmap(b)
                    if (b == null) imageExec.execute {
                        val t = try { contentResolver.loadThumbnail(p.uri, Size(300, 300), null) } catch (e: Exception) { null }
                        ui.post { if (t != null) small.put(p.id, t); if (iv.tag == p.id) iv.setImageBitmap(t) }
                    }
                    return iv
                }
            }
            setOnItemClickListener { _, _, position, _ ->
                val p = items[position]
                trash.remove(p.id); keep.add(p.id); saveDecisions()
                toast("Wird behalten"); showTrash()
            }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10); bottomMargin = dp(10) })
        root.addView(button("Alle ${items.size} in den Papierkorb", RED) { requestTrash() }, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    @Suppress("DEPRECATION")
    private fun requestTrash() {
        if (trash.isEmpty()) return toast("Nichts zum Löschen vorgemerkt.")
        pendingTrash = trash.take(1000)
        val uris = pendingTrash.map { ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, it) }
        try {
            val pi = MediaStore.createTrashRequest(contentResolver, uris, true)
            startIntentSenderForResult(pi.intentSender, REQ_TRASH, null, 0, 0, 0)
        } catch (e: Exception) {
            toast("Löschen wurde vom System abgelehnt.")
        }
    }

    @Deprecated("Activity API")
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_TRASH) return
        if (resultCode == RESULT_OK) {
            val n = pendingTrash.size
            trash.removeAll(pendingTrash.toSet())
            saveDecisions()
            toast("$n Fotos in den Papierkorb verschoben" + if (trash.isNotEmpty()) ". Noch ${trash.size} übrig, bitte nochmal tippen." else "")
            loadPhotos()
        } else toast("Abgebrochen, nichts gelöscht.")
    }

    @Deprecated("Activity API")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (screen != "start") showStart() else super.onBackPressed()
    }

    // ---------- Hilfen ----------

    private fun saveDecisions() {
        prefs.edit()
            .putStringSet("keep", keep.map { it.toString() }.toSet())
            .putStringSet("trash", trash.map { it.toString() }.toSet())
            .apply()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int) = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(color) }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(s: String, bg: Int, fg: Int = Color.WHITE, onClick: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 16f; setTextColor(fg)
        background = rounded(bg)
        stateListAnimator = null
        setPadding(dp(16), dp(14), dp(16), dp(14))
        setOnClickListener { onClick() }
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(BG)
        setPadding(dp(20), dp(28), dp(20), dp(28))
    }

    private fun LinearLayout.add(v: View, top: Int = 12) {
        addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
